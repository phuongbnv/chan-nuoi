<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index(){
        $users = DB::table('users')
        ->join('profile','profile.id_user','users.id')
        ->get();
        return view('admin.users',['users'=>$users]);
    }
    public function register(Request $request){
        
        
        if ($request->getMethod() == 'GET') {
            return view('register',['gioithieu'=> $request->gioithieu]);
        }
        if (is_null($request->code)){
            $invate = null;
        }else{
            $invate = $request->code;
        }
        $this->validate(request(), [
            'phone' => 'required|unique:users|min:9|max:10',
            'password' => 'required',
            'password_confirm' => 'required|same:password' 
        ]);
        $user = DB::table('users')->insert([
            'phone' => $request->phone,
            'password' => Hash::make($request->password)
        ]);
        
        if($user){            
            $users = DB::table('users')->max('id');
            $profile = DB::table('profile')->insert([
                'id_user' => $users,
                'level' => 0,
                'money' => 50000,
                'invite_code_father' => $invate,
                'invite_code' => $users+100000,     
                'created_at'=>new \DateTime()       
            ]);
            $alert='Đăng ký thành công';
            return redirect()->route('login')->with('alert',$alert);
        }else{
            $alert='Đăng ký không thành công';

            return redirect()->back()->with('alert',$alert);
        }
    }
    
    public function login(Request $request){
        if ($request->getMethod() == 'GET') {
            if (Auth::check()) {
                return redirect()->route('page.home');
            }
            return view('login');
        }
        $credentials = $request->only(['phone', 'password']);
        if (Auth::attempt($credentials)) {           
            $alert='login thành công';
            return redirect()->route('page.home')->with('alert',$alert);
        } else {
            $alert='login không thành công';

            return redirect()->back()->with('alert',$alert);
        }
    }
    public function logout(){
        Auth::logout();
        return redirect()->route('login');
    }
}
