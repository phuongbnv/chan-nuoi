<div class="menu">
    <div class="sub text-center">
        <a href="<?php echo e(route('page.home')); ?>">Home</a>
    </div>
    <div class="sub text-center">
        <a href="<?php echo e(route('page.trang_trai')); ?>">Trang Trại</a>
    </div>
    <div class="sub text-center">
        <a href="<?php echo e(route('page.home')); ?>">Tiết Kiệm</a>
    </div>
    <div class="sub text-center">
        <a href="<?php echo e(route('page.pagelink')); ?>">Link Mời</a>
    </div>
    <div class="sub text-center">
        <a href="<?php echo e(route('page.profie')); ?>">Cá Nhân</a>
    </div>
</div>
<style>
    .menu{
        display: flex;
        width: 100%;
    }
    .menu .sub{
        width: 20%;
    }
    .menu .sub a{
        text-transform: uppercase;
        text-decoration: none;
        color: white;
    }
</style><?php /**PATH D:\xampp\htdocs\project\app\resources\views/page/layout/menu.blade.php ENDPATH**/ ?>