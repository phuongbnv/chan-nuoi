
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Danh sách User</h1>
    

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Số điện thoại</th>
                            <th>Số dư</th>
                            <th>level</th>
                            <th>Số tài khoản</th>
                            <th>Tên ngân hàng</th>
                            <th>Mã giới thiệu</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e(number_format($user->money)); ?></td>
                            <td><?php echo e($user->level); ?></td>
                            <td><?php echo e($user->number_bank); ?></td>
                            <td><?php echo e($user->brank_bank); ?></td>
                            <td><?php echo e($user->invite_code); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<style>
    .dataTables_filter, .dataTables_paginate{
    float:right;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/admin/users.blade.php ENDPATH**/ ?>