
<?php $__env->startSection('content'); ?>
<div class="wrapper">    
    <div class="row">
        <div class="tablink col-md-6 text-center" id="defaultOpen" onclick="openPage('thu-nhap', this,'#0dcaf0')">
            Thu Nhập
        </div>
        <div class="tablink col-md-6 text-center" onclick="openPage('hoan-thanh', this,'#0dcaf0')">
            Hoàn Thành
        </div>
    </div>
    
    <div class="section2">
        <div class="row">    
            <div id="thu-nhap" class="tabcontent">
                <div class="trai-nghiem">
                    <div class="box-shadown">
                        <div class="time">
                            Thời gian chăn nuôi
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-4 text-center">
                                <p class="money">5,000</p>
                                <p>Thu nhập mỗi ngày</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Lợi nhuận dự kiến</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Phí nhận nuôi</p>
                            </div>
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-1">
                                <img src="" alt="img1">
                            </div>
                            <div class="col-md-11">
                                <h5>Angus calf SY-0098</h5>
                                <span>Đang trong thời gian chăn nuôi</span>                                
                            </div>
                        </div>
                        <div class="col-md-12 con-lai mt-2">
                            <div style="position: relative;">
                                <span> Còn 21 giờ nữa hoàn thành</span>
                            </div>
                        </div>                        
                    </div>            
                </div>  
                <div class="trai-nghiem">
                    <div class="box-shadown">
                        <div class="time">
                            Thời gian chăn nuôi
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-4 text-center">
                                <p class="money">5,000</p>
                                <p>Thu nhập mỗi ngày</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Lợi nhuận dự kiến</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Phí nhận nuôi</p>
                            </div>
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-1">
                                <img src="" alt="img1">
                            </div>
                            <div class="col-md-11">
                                <h5>Angus calf SY-0098</h5>
                                <span>Đang trong thời gian chăn nuôi</span>                                
                            </div>
                        </div>
                        <div class="col-md-12 con-lai mt-2">
                            <div style="position: relative;">
                                <span> Còn 21 giờ nữa hoàn thành</span>
                            </div>
                        </div>                        
                    </div>            
                </div>  
            </div>

            <div id="hoan-thanh" class="tabcontent">
                <div class="trai-nghiem">
                    <div class="box-shadown">
                        <div class="time">
                            Hoàn thành
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-4 text-center">
                                <p class="money">5,000</p>
                                <p>Thu nhập mỗi ngày</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Lợi nhuận dự kiến</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <p class="money">50,000</p>
                                <p>Phí nhận nuôi</p>
                            </div>
                        </div>
                        <div class="col-md-12 row mt-4">
                            <div class="col-md-1">
                                <img src="" alt="img1">
                            </div>
                            <div class="col-md-11">
                                <h5>Angus calf SY-0098</h5>
                                <span>Đang trong thời gian chăn nuôi</span>                                
                            </div>
                        </div>
                        <!-- <div class="col-md-12 con-lai mt-2">
                            <div style="position: relative;">
                                <span> Còn 21 giờ nữa hoàn thành</span>
                            </div>
                        </div>                         -->
                    </div>            
                </div>
                </div>
            </div>      
                                             
        </div>        
    </div>
    
    
</div>
<style>
.tablink{
    padding: 15px;
    color: white;
    cursor: default;
}
.con-lai span {
    display: inline;
    border: 1px solid;
    padding: 10px 50px;
    border-radius: 50px;
    position: absolute;
    right: 0;
    top: -40px;
}
.time {
    position: absolute;
    top: 0;
    right: 0;
    background: #30a569;
    border-radius: 0 20px;
    padding: 5px 25px;
    color: white;
}
.nap-tien button{
    float:right; 
    color:white;
    padding: 10px 50px;
}
.box-shadown {
    box-shadow: 0px 0px 8px 0px #adadad;
    border-radius: 20px;
    padding: 20px;
    margin:20px 0px ;
    background: #eaeaea;
}
.box-shadown ul {
    list-style: none;
    padding: 0;
}
.box-shadown ul li {
    padding: 12px 5px;
    border-top: 1px solid #cccccc;
}
.box-shadown ul li a{
    text-decoration:none;
    color: #383838;
}
.box-shadown button {
    margin-left: 40px;
    border-radius: 10px;
}
.box-shadown p .money{
    font-size:20px
}
.trai-nghiem .title, .bxh .title {
    border-left: 5px solid #4087f1;
    padding-left: 10px;
    margin-top:20px
}
.trai-nghiem{
    position: relative;
}
.bxh{
    margin-top: 50px
}
.money{
    color:#30a569;
}
</style>
<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\app\resources\views/page/trang-trai.blade.php ENDPATH**/ ?>