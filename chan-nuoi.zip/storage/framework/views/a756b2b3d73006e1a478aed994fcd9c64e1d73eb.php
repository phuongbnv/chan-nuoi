<div class="header"> 
    <div class="slide">
        <div class="slideshow-container">
            <?php for($i=1;$i<=5;$i++): ?>
            <div class="mySlides fade">
                <img src="<?php echo e(asset('img/slide'.$i.'.jpeg')); ?>" style="width:100%; height:350px">
                <div class="text">Caption <?php echo e($i); ?></div>
            </div>
            <?php endfor; ?>

        </div>
        <br>

        <div style="text-align:center;display:none">
            <?php for($i=1;$i<=5;$i++): ?>
                <span class="dot"></span>
            <?php endfor; ?>
        </div>
    </div>
</div>
<style>
    .fade:not(.show){
        opacity: 1 !important;
    }
</style><?php /**PATH D:\xampp\htdocs\project\app\resources\views/page/layout/header.blade.php ENDPATH**/ ?>