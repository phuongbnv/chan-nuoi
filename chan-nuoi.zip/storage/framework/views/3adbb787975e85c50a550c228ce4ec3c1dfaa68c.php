
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Sửa sản phẩm</h1>
    <?php if(session('alert')): ?>
        <section class='alert alert-success'><?php echo e(session('alert')); ?></section>
    <?php elseif($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('product.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

        <div class="form-group">
            <label for="exampleInputEmail1">Tên</label>
            <input value="<?php echo e($product->name); ?>" name="name" required type="text" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleFormControlFile1">ảnh</label>
            <img width="200px" src="<?php echo e(asset('img/product/'.$product->image)); ?>" alt="">
            <input value="<?php echo e($product->image); ?>" name="image" type="file" class="form-control-file" id="exampleFormControlFile1">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Phí nhận nuôi</label>
            <input value="<?php echo e($product->phi_nhan_nuoi); ?>" required name="phi_nhan_nuoi" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Phí giảm giá</label>
            <input value="<?php echo e($product->phi_giam_gia); ?>" required name="phi_giam_gia" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">lợi nhuận</label>
            <input value="<?php echo e($product->loi_nhan); ?>" required name="loi_nhuan" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">thời gian</label>
            <input value="<?php echo e($product->time); ?>" required name="time" type="number" class="form-control" >
        </div>
        <button type="submit" class="btn btn-primary float-right">Submit</button>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>