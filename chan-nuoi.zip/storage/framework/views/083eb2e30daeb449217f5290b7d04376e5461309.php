
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Danh sách nạp tiền</h1>
    

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Account user</th>
                            <th>Phương thức</th>
                            <th>tiền nạp</th>
                            <th>Ngày nạp</th>
                            <th>level</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td><?php echo e($value->id); ?></td>   
                            <td><?php echo e($value->phone); ?></td>
                            <td><?php echo e($value->phuong_thuc); ?></td>
                            <td><?php echo e(number_format($value->number_money)); ?></td>
                            <td><?php echo e($value->created_at); ?></td>
                            <td>
                                <select id="level-<?php echo e($value->id); ?>">
                                    <?php for($i = 0; $i < 6; $i++): ?>
                                        <?php if($value->level == $i): ?>
                                        <option value="<?php echo e($i); ?>" selected = 'selected'><?php echo e($i); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </select>
                            </td>
                            <td>
                                <?php if($value->active == 0): ?>
                                <input type="hidden" value="<?php echo e($value->id); ?>" name="id">
                                <button onclick="duyet(<?php echo e($value->id); ?>)" class="badge bg-info rounded-pill">duyệt</button>
                                <?php elseif($value->active == 1): ?>
                                <div id="status" class="badge bg-warning rounded-pill">Đã duyệt</div>
                                <?php endif; ?>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<style>
    .dataTables_filter, .dataTables_paginate{
    float:right;
    }
</style>
<script type="text/javascript">
    function duyet($id){
        $level = $('#level-'+$id).val()
        if (confirm('Bạn có muốn duyệt')) {
          // Save it!
          $.ajax({
            url:"<?php echo e(route('admin.duyet')); ?>", 
            method:"POST", 
            data:{
                    "_token" : '<?php echo e(csrf_token()); ?>',
                    "id"     : $id,
                    "level"  : $level,
                },
            success:function(data){   
                alert(data);
                location.reload();
            }
        });
        } else {
          // Do nothing!
          console.log('Thing was not saved to the database.');
        }
        

    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/admin/deposit.blade.php ENDPATH**/ ?>