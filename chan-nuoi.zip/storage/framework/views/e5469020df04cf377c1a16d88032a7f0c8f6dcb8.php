
<?php $__env->startSection('content'); ?>
<div class="wrapper">    
    <div class="section2">
        <div class="row">          
            <div class="trai-nghiem">
                <div class="box-shadown row">
                    <div class="col-md-12 row">
                        <div class="col-md-1">
                            <img class="icon-2 pr-5" src="<?php echo e(asset('img/icon/user.png')); ?>" alt="user">
                        </div>
                        <div class="col-md-11">
                                <h5><?php echo e($users->phone); ?> (Level : <?php echo e($users->level); ?>)</h5>
                            <span>Mã mời: <span id="copy" ><?php echo e($users->invite_code); ?></span></span>
                            <!-- <input id="copy" type="hidden" value="<?php echo e($users->invite_code); ?>"> -->
                            <button onclick="copy()" class="button">Sao chép</button>
                        </div>
                    </div>
                    <div class="col-md-12 row mt-5">
                        <div class="col-md-4 text-center">
                            <p class="money"><?php echo e(number_format($users->money)); ?></p>
                            <p>Tài sản của tôi</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money"><?php echo e(count($hoan_thanh)); ?></p>
                            <p>Số vật nuôi hoàn thành</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money"><?php echo e($count); ?></p>
                            <p>Giới thiệu được</p>
                        </div>
                    </div>
                </div>            
            </div>
            <div>
                <div class="box-shadown row">
                    <!-- <div class="col-2 col-0"></div> -->
                    <div class="col-6"><a href="<?php echo e(route('page.deposit')); ?>"><button style="width:90%" type="button" class="btn btn-info text-white"><img class="icon" src="<?php echo e(asset('img/icon/money.png')); ?>" alt="">&nbsp;Nạp Tiền</button></a></div>
                    <div class="col-6"><a href="<?php echo e(route('page.withdraw')); ?>"><button style="width:90%" type="button" class="btn btn-info text-white"><img class="icon" src="<?php echo e(asset('img/icon/atm.png')); ?>" alt="">&nbsp;Rút Tiền</button></a></div>
                </div>
            </div>
            
            <div>
                <div class="box-shadown">
                    <ul>
                        <li class="border-0"><a href="<?php echo e(route('page.upgrade_account')); ?>"><img class="icon" src="<?php echo e(asset('img/icon/level-up.png')); ?>" alt="">&nbsp;Nâng cấp tài khoản</a> </li>
                        <li><a href="<?php echo e(route('page.setting_account')); ?>"><img class="icon" src="<?php echo e(asset('img/icon/user.png')); ?>" alt="">&nbsp;Thông tin người dùng</a></li>
                        <li><a href="<?php echo e(route('page.income')); ?>"><img class="icon" src="<?php echo e(asset('img/icon/icons8-transaction-64.png')); ?>" alt="">&nbsp;Thu nhập của tôi</a></li>
                        <li><a href="<?php echo e(route('page.transaction_history')); ?>"><img class="icon" src="<?php echo e(asset('img/icon/level-up.png')); ?>" alt="">&nbsp;Lịch sử giao dịch</a></li>
                        <li><a href="<?php echo e(route('logout')); ?>"><img class="icon" src="<?php echo e(asset('img/icon/level-up.png')); ?>" alt="">&nbsp;Đăng xuất</a></li>
                    </ul>
                </div>
            </div>                                    
        </div>        
    </div>
</div>
<style>

.nap-tien button{
    float:right; 
    color:white;
    padding: 10px 50px;
}
.box-shadown {
    box-shadow: 0px 0px 8px 0px #adadad;
    border-radius: 10px;
    padding: 20px;
    margin:20px 0px ;
    background: #eaeaea;
}
.box-shadown ul {
    list-style: none;
    padding: 0;
}
.box-shadown ul li {
    padding: 12px 5px;
    border-top: 1px solid #cccccc;
}
.box-shadown ul li a{
    text-decoration:none;
    color: #383838;
}
.box-shadown button {
    margin-left: 40px;
    border-radius: 10px;
}
.box-shadown p .money{
    font-size:20px
}
.trai-nghiem .title, .bxh .title {
    border-left: 5px solid #4087f1;
    padding-left: 10px;
    margin-top:20px
}
.bxh{
    margin-top: 50px
}
.money{
    color:#30a569;
}
.icon-2{
        width:60px;
    }
.box-shadown .button {
    margin-left: 0px;
    border-radius: 10px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/page/profie.blade.php ENDPATH**/ ?>