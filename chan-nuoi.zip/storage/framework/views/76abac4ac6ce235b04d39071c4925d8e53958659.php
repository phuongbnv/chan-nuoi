
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Thêm sản phẩm</h1>
    <?php if(session('alert')): ?>
        <section class='alert alert-success'><?php echo e(session('alert')); ?></section>
    <?php elseif($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Tên</label>
            <input name="name" required type="text" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleFormControlFile1">ảnh</label>
            <input name="image" required type="file" class="form-control-file" id="exampleFormControlFile1">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Phí nhận nuôi</label>
            <input required name="phi_nhan_nuoi" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Phí giảm giá</label>
            <input required name="phi_giam_gia" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">lợi nhuận</label>
            <input required name="loi_nhuan" type="number" class="form-control" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">thời gian</label>
            <input required name="time" type="number" class="form-control" >
        </div>
        <button type="submit" class="btn btn-primary float-right">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/admin/product/add.blade.php ENDPATH**/ ?>