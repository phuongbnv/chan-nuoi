
<?php $__env->startSection('content'); ?>
<div class="wrapper">    
    <div class="section2">
        <div class="row">          
            <div class="trai-nghiem">
                <div class="box-shadown">
                    <div class="col-md-12 row">
                        <div class="col-md-1">
                            <img src="" alt="img1">
                        </div>
                        <div class="col-md-11">
                            <h5>My account( 0123456789 )</h5>
                            <span>Mã mời: <span>123123</span></span>
                            <button>Mã mời</button>
                        </div>
                    </div>
                    <div class="col-md-12 row mt-5">
                        <div class="col-md-4 text-center">
                            <p class="money">5000</p>
                            <p>Tài sản của tôi</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">1</p>
                            <p>Số vật nuôi hàng thành</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">11</p>
                            <p>Giới thiệu được</p>
                        </div>
                    </div>
                </div>            
            </div>
            <div>
                <div class="box-shadown row">
                    <div class="col-2"></div>
                    <div class="col-5"><button style="width:90%" type="button" class="btn btn-info text-white">Nạp Tiền</button></div>
                    <div class="col-5"><button style="width:90%" type="button" class="btn btn-info text-white">Rút Tiền</button></div>
                </div>
            </div>
            
            <div>
                <div class="box-shadown">
                    <ul>
                        <li class="border-0"><a href="">Nâng cấp tài khoản</a> </li>
                        <li><a href="">Thông tin người dùng</a></li>
                        <li><a href="">Thu nhập của tôi</a></li>
                        <li><a href="">Lịch sử giao dịch</a></li>
                        <li><a href="<?php echo e(route('page.logout')); ?>">Đăng xuất</a></li>
                    </ul>
                </div>
            </div>                        
        </div>
        
    </div>
</div>
<style>
.nap-tien button{
    float:right; 
    color:white;
    padding: 10px 50px;
}
.box-shadown {
    box-shadow: 0px 0px 8px 0px #adadad;
    border-radius: 10px;
    padding: 20px;
    margin:20px 0px ;
    background: #eaeaea;
}
.box-shadown ul {
    list-style: none;
    padding: 0;
}
.box-shadown ul li {
    padding: 12px 5px;
    border-top: 1px solid #cccccc;
}
.box-shadown ul li a{
    text-decoration:none;
    color: #383838;
}
.box-shadown button {
    margin-left: 40px;
    border-radius: 10px;
}
.box-shadown p .money{
    font-size:20px
}
.trai-nghiem .title, .bxh .title {
    border-left: 5px solid #4087f1;
    padding-left: 10px;
    margin-top:20px
}
.bxh{
    margin-top: 50px
}
.money{
    color:#30a569;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\app\resources\views/page/profie.blade.php ENDPATH**/ ?>