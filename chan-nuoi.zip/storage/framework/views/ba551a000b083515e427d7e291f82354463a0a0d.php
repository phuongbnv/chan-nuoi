
<?php $__env->startSection('content'); ?>
<div class="header">
    <?php echo $__env->make('page.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="wrapper">
    <div class="section1">
        <div class="row">
            <div class="account col-md-6">
                <p>Name account</p>
                <p>Số Dư: <span class="money">1,000,000 VNĐ</span></p>
            </div>
            <div class="nap-tien col-md-6">
                <button type="button" class="btn btn-info"><i>+ </i>Nạp Tiền</button>
            </div>
        </div>        
    </div>
    <div class="section2">
        <div class="row">           

            <div class="trai-nghiem">
                <p class="title">Trải nghiệm (Nhận nuôi một lần)</p>                    
                <div class="box-shadown">
                    <div class="col-md-12 row">
                        <div class="col-md-1">
                            <img src="" alt="img1">
                        </div>
                        <div class="col-md-11">
                            <h5>Angus calf SY-0098</h5>
                            <p>Phí nhận nuôi: <span class="money"><del>99,000 vnđ</del></span></p>
                        </div>
                    </div>
                    <div class="col-md-12 row mt-4">
                        <div class="col-md-4 text-center">
                            <p class="money">5000</p>
                            <p>Lợi Nhuận/ Ngày</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">1</p>
                            <p>Thời gian chăn nuôi (Ngày)</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">50,000</p>
                            <p>Phí nhận nuôi</p>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <button type="button" class="btn btn-info text-white col-10">Nhận nuôi</button>                        
                    </div>
                </div>           
            </div>

            <!-- bảng xếp hạng  -->
            <div class="bxh">
                <p class="title">Bảng xếp hạng kiếm tiền</p>
                <div class="box-shadown">
                    <div class="col-md-12 row">
                        <div class="col-md-1">
                            <img src="" alt="img1">
                        </div>
                        <div class="col-md-11">
                            <h5>Name Account <span class="money">Top</span></h5>
                            <p>Cấp độ: <span class="money">Vip</span></p>
                        </div>
                    </div>
                    <div class="col-md-12 row mt-4">
                        <div class="col-md-4 text-center">
                            <p class="money">5000</p>
                            <p>Thu Nhập</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">1</p>
                            <p>Giới thiệu người</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">50,000</p>
                            <p>Tài sản</p>
                        </div>
                    </div>
                </div>  
                <div class="box-shadown">
                    <div class="col-md-12 row">
                        <div class="col-md-1">
                            <img src="" alt="img1">
                        </div>
                        <div class="col-md-11">
                            <h5>Name Account <span class="money">Top</span></h5>
                            <p>Cấp độ: <span class="money">Vip</span></p>
                        </div>
                    </div>
                    <div class="col-md-12 row mt-4">
                        <div class="col-md-4 text-center">
                            <p class="money">5000</p>
                            <p>Thu Nhập</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">1</p>
                            <p>Giới thiệu người</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <p class="money">50,000</p>
                            <p>Tài sản</p>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
        
    </div>
</div>
<style>
.nap-tien button{
    float:right; 
    color:white;
    padding: 10px 50px;
}
.box-shadown {
    box-shadow: 0px 0px 8px 0px #adadad;
    border-radius: 10px;
    padding: 20px;
    margin:20px 0px ;
}
.box-shadown button {
    margin-left: 40px;
    border-radius: 10px;
}
.box-shadown p .money{
    font-size:20px
}
.trai-nghiem .title, .bxh .title {
    border-left: 5px solid #4087f1;
    padding-left: 10px;
    margin-top:20px
}
.bxh{
    margin-top: 50px
}
.money{
    color: #d41111;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\app\resources\views/page/home.blade.php ENDPATH**/ ?>