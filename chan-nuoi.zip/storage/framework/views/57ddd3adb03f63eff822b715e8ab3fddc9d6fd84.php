
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Danh sách rút tiền</h1>
    

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Account user</th>
                            <th>Phương thức</th>
                            <th>Số Momo</th>
                            <th>Số Tài khoản</th>
                            <th>Tên tài khoản</th>
                            <th>Tên ngân hàng</th>
                            <th>tiền rút</th>
                            <th>Ngày rút</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->id); ?></td>   
                            <td><?php echo e($value->phone); ?></td>
                            <td><?php echo e($value->phuong_thuc); ?></td>
                            <td><?php echo e($value->number_momo); ?></td>
                            <td><?php echo e($value->number_bank); ?></td>
                            <td><?php echo e($value->name_bank); ?></td>
                            <td><?php echo e($value->brank_bank); ?></td>
                            <td><?php echo e(number_format($value->number_money)); ?></td>
                            <td><?php echo e($value->created_at); ?></td>
                            <td>
                                <?php if($value->active == 0): ?>
                                <input type="hidden" value="<?php echo e($value->id); ?>" name="id">
                                <button onclick="duyet(<?php echo e($value->id); ?>)" class="badge bg-info rounded-pill">duyệt</button>
                                <?php elseif($value->active == 1): ?>
                                <div id="status" class="badge bg-warning rounded-pill">Đã duyệt</div>
                                <?php endif; ?>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<style>
    .dataTables_filter, .dataTables_paginate{
    float:right;
    }
</style>
<script type="text/javascript">
    function duyet($id){
        $.ajax({
            url:"<?php echo e(route('admin.duyetrut')); ?>", 
            method:"POST", 
            data:{
                    "_token" : '<?php echo e(csrf_token()); ?>',
                    "id"     : $id
                },
            success:function(data){   
                alert(data)
                window.location.assign('withdraw');

        }
    });

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project\chan-nuoi\resources\views/admin/withdraw.blade.php ENDPATH**/ ?>